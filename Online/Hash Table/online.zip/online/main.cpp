#include<bits/stdc++.h>
#include "hash.h"
using namespace std::chrono;

int main(){

    //for faster io operations
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);

    //tie console to file
    freopen("input.txt", "r", stdin);
    freopen("output.txt", "w", stdout);

    powerCalculation();
    


    long long int i,j,x,y,count;
    double totalProbeNumber;
    long long int n;    // Length Of Hash Table( given as input)
    vector<double>load_factor={.4, .5, .6, .7, .8, .9}; // Load Factor = (n / word_count)
    long long int loadFactorCount=6;  //Number Of Load Factor
    vector<long long int> searchIndex;  //Indices Of Inserted Words
    vector<long long int> deleteIndex;  //Indices Of Deleted Words
    vector<long long int> mixedIndex;    //Half The Indices Are Already Deleted 
    vector<double> schBeforeDeleteTime(loadFactorCount),schAfterDeleteTime(loadFactorCount);
    vector<double> linearProbingBeforeDeleteTime(loadFactorCount),linearProbingAfterDeleteTime(loadFactorCount),linearProbingBeforeDeleteProbeCount(loadFactorCount),linearProbingAfterDeleteProbeCount(loadFactorCount);
    vector<double> quadreticProbingBeforeDeleteTime(loadFactorCount),quadreticProbingAfterDeleteTime(loadFactorCount),quadreticProbingBeforeDeleteProbeCount(loadFactorCount),quadreticProbingAfterDeleteProbeCount(loadFactorCount);
    vector<double> doubleHashingBeforeDeleteTime(loadFactorCount),doubleHashingAfterDeleteTime(loadFactorCount),doubleHashingBeforeDeleteProbeCount(loadFactorCount),doubleHashingAfterDeleteProbeCount(loadFactorCount);
    long long int wordCount;   //Number Of Random Words Generated 
    long long int wordCountOf5; //10% Of Randomly Generated Word 
    long long int wordCountOf10; //5% Of Randomly Generated Word 
    double timeDiv=1000000; //Nano Second -> Mili Second
    map<long long int,long long int>mp;
    pair<long long int,long long int> p;
    vector<string>v;

    double loadValue;
    cin>>n>>loadValue;
    long long int unique_hash1=checkUniqueHash1(randomStringGenerator(100),n);
    long long int unique_hash2=checkUniqueHash2(randomStringGenerator(100),n);

    cout<<"Hash Table Length: "<<n<<endl;
    checkHashUniqueValues(randomStringGenerator(100),n);

    auto start = high_resolution_clock::now();
    auto stop = high_resolution_clock::now();
    auto duration = duration_cast<nanoseconds>(stop - start);

    seperateChainHashing seperateChainHashing;
    linearProbing linearProbing;
    quadraticProbing quadraticProbing;
    doubleHashing doubleHashing;

    for(i=0;i<loadFactorCount;i++){

        wordCount=loadValue*n; //For each load factor
        // wordCountOf5=wordCount*0.05;
        // wordCountOf10=wordCountOf5*2;

        v=randomStringGenerator(wordCount);

        seperateChainHashing.initialize(n);
        linearProbing.initialize(n);
        quadraticProbing.initialize(n);
        doubleHashing.initialize(n);
        //cout<<"we are here"<<endl;
       
        //Insert Elements To All Hash Tables
        int counter=0;
        for(j=0;j<wordCount;j++){
            counter++;
            seperateChainHashing.insert(v[j],j+1);
            if(counter%100==0){
                int count  = seperateChainHashing.chainLength();
                if(count>10){
                    cout<<"Current chain max length is :"<<count<<endl;
                    seperateChainHashing.rehash(wordCount, 1.2, v , wordCount);
                }
            }
        
            
            //cout<<"we are here 1"<<endl;
        //     linearProbing.insert(v[j],j+1);
        //    // cout<<"we are here 2" <<endl;
        //     quadraticProbing.insert(v[j],j+1);
        //     //cout<<"we are here 3"<<endl;
        //     doubleHashing.insert(v[j],j+1);
        //    // cout<<"we are here 4"<<endl;
        }
       //cout<<"we are here"<<endl;
        //Picking 10% Elements To Seacrh
        count=0;
        srand(time(0));
        while(count<wordCountOf10){
            x=rand()%wordCount;
            if(mp[x]==0){
                searchIndex.push_back(x);
                count++;
                mp[x]=1;
            }
        }
        mp.clear();
        //cout<<"we are here"<<endl;

        //Separate Chaining Hash Search Before Deletion
        start = high_resolution_clock::now();
        //Time it takes to search 10% of the words
        for(j=0;j<wordCountOf10;j++){
            seperateChainHashing.search(v[searchIndex[j]]);
        }
        stop = high_resolution_clock::now();
        duration = duration_cast<nanoseconds>(stop - start);
        schBeforeDeleteTime[i]=duration.count()/(wordCountOf10*timeDiv);
        
        //Linear Probing Search Before Deletion
        totalProbeNumber=0;
        start = high_resolution_clock::now();
        for(j=0;j<wordCountOf10;j++){
            p=linearProbing.search(v[searchIndex[j]]);
            totalProbeNumber+=p.second;
        }
        stop = high_resolution_clock::now();
        duration = duration_cast<nanoseconds>(stop - start);
        linearProbingBeforeDeleteTime[i]=duration.count()/(wordCountOf10*timeDiv);
        linearProbingBeforeDeleteProbeCount[i]=totalProbeNumber/wordCountOf10;

        //Quadratic Probing Search Before Deletion
        totalProbeNumber=0;
        start = high_resolution_clock::now();
        for(j=0;j<wordCountOf10;j++){
            p=quadraticProbing.search(v[searchIndex[j]]);
            totalProbeNumber+=p.second;
        }
        stop = high_resolution_clock::now();
        duration = duration_cast<nanoseconds>(stop - start);
        quadreticProbingBeforeDeleteTime[i]=duration.count()/(wordCountOf10*timeDiv);
        quadreticProbingBeforeDeleteProbeCount[i]=totalProbeNumber/wordCountOf10;

        //Double Hashing Search Before Deletion
        totalProbeNumber=0;
        start = high_resolution_clock::now();
        for(j=0;j<wordCountOf10;j++){
            p=doubleHashing.search(v[searchIndex[j]]);
            totalProbeNumber+=p.second;
        }
        stop = high_resolution_clock::now();
        duration = duration_cast<nanoseconds>(stop - start);
        doubleHashingBeforeDeleteTime[i]=duration.count()/(wordCountOf10*timeDiv);
        doubleHashingBeforeDeleteProbeCount[i]=totalProbeNumber/wordCountOf10;

        //Picking 10%  Elements To Delete
        count=0;
        srand(time(0));
        while(count<wordCountOf10){
            x=rand()%wordCount;
            if(mp[x]==0){
                deleteIndex.push_back(x);
                count++;
                mp[x]=1;
            }
        }
        mp.clear();
        
        //Delete Elements From All Hash Tables
        int counter2 = 0 ;
        for(j=0;j<wordCountOf10;j++){
            counter2++;

            seperateChainHashing.removee(v[deleteIndex[j]]);
            if(counter2%100==0){
                int count = seperateChainHashing.chainLength();
                if(count<3)
                    seperateChainHashing.rehash(wordCount, .8, v, wordCount);
            }

            // linearProbing.removee(v[deleteIndex[j]]);
            // quadraticProbing.removee(v[deleteIndex[j]]);
            // doubleHashing.removee(v[deleteIndex[j]]);
        }
      
        //Pick Elements 10% Elements To Search (5% From Deleted, 5% From hash Table)

        //5% From Deleted
        count=0;
        srand(time(0));
        while(count<wordCountOf5){
            x=deleteIndex[rand()%wordCountOf10];
            if(mp[x]==0){
                mixedIndex.push_back(x);
                count++;
                mp[x]=1;
            }
        }

        //Marking All Deleted Indices So That They Don't Get Chosen Again  
        for(j=0;j<wordCountOf10;j++){
            mp[deleteIndex[j]]=1;
        }

        //5% From Hash Table
        count=0;
        while(count<wordCountOf5){
            x=rand()%wordCount;
            if(mp[x]==0){
                mixedIndex.push_back(x);
                count++;
                mp[x]=1;
            }
        }
        mp.clear();

        
        //Separate Chaining Hash Search After Deletion
        start = high_resolution_clock::now();
        for(j=0;j<wordCountOf10;j++){
            seperateChainHashing.search(v[mixedIndex[j]]);
        }
        stop = high_resolution_clock::now();
        duration = duration_cast<nanoseconds>(stop - start);
        schAfterDeleteTime[i]=duration.count()/(wordCountOf10*timeDiv);

        //Linear Probing Search After Deletion
        totalProbeNumber=0;
        start = high_resolution_clock::now();
        for(j=0;j<wordCountOf10;j++){
            p=linearProbing.search(v[mixedIndex[j]]);
            totalProbeNumber+=p.second;
        }
        stop = high_resolution_clock::now();
        duration = duration_cast<nanoseconds>(stop - start);
        linearProbingAfterDeleteTime[i]=duration.count()/(wordCountOf10*timeDiv);
        linearProbingAfterDeleteProbeCount[i]=totalProbeNumber/wordCountOf10;

        //Quadratic Probing Search After Deletion
        totalProbeNumber=0;
        start = high_resolution_clock::now();
        for(j=0;j<wordCountOf10;j++){
            p=quadraticProbing.search(v[mixedIndex[j]]);
            totalProbeNumber+=p.second;
        }
        stop = high_resolution_clock::now();
        duration = duration_cast<nanoseconds>(stop - start);
        quadreticProbingAfterDeleteTime[i]=duration.count()/(wordCountOf10*timeDiv);
        quadreticProbingAfterDeleteProbeCount[i]=totalProbeNumber/wordCountOf10;

        //Double Hashing Search After Deletion
        totalProbeNumber=0;
        start = high_resolution_clock::now();
        for(j=0;j<wordCountOf10;j++){
            p=doubleHashing.search(v[mixedIndex[j]]);
            totalProbeNumber+=p.second;
        }
        stop = high_resolution_clock::now();
        duration = duration_cast<nanoseconds>(stop - start);
        doubleHashingAfterDeleteTime[i]=duration.count()/(wordCountOf10*timeDiv);
        doubleHashingAfterDeleteProbeCount[i]=totalProbeNumber/wordCountOf10;

        searchIndex.clear();
        deleteIndex.clear();
        mixedIndex.clear();


        seperateChainHashing.clear();
        linearProbing.clear();
        quadraticProbing.clear();
        doubleHashing.clear();
    }

    cout<<"\n";
    cout<<"Table 1: Performance of separate chaining in various load factors"<<endl;
    cout<<" _________________________________________________________________"<<endl;
    cout<<"|                   |   Before Deletion   |     After Deletion    |"<<endl;
    cout<<"|___________________|_____________________|_______________________|"<<endl;
    cout<<"|    Load Factor    |   Avg Search Time   |    Avg Search Time    |"<<endl;
    cout<<"|___________________|_____________________|_______________________|"<<endl;
    for(i=0;i<loadFactorCount;i++){
    cout<<fixed<<setprecision(5)<<"|      "<<load_factor[i]<<"     |      "<<schBeforeDeleteTime[i]<<"ms     |      "<<schAfterDeleteTime[i]<<"ms       |"<<endl;
    cout<<"|___________________|_____________________|_______________________|"<<endl;
    }

    // cout<<"\n";
    // cout<<"Table 2: Performance of linear probing in various load factors"<<endl;
    // cout<<" ____________________________________________________________________________________________________________"<<endl;
    // cout<<"|                          |             Before Deletion            |              After Deletion            |"<<endl;
    // cout<<"|__________________________|________________________________________|________________________________________|"<<endl;
    // cout<<"|        Load Factor       |  Avg Search Time  |  Avg Num. Of Probe |  Avg Search Time  |  Avg Num. Of Probe |"<<endl;
    // cout<<"|__________________________|___________________|____________________|___________________|____________________|"<<endl;
    // for(i=0;i<loadFactorCount;i++){
    // cout<<fixed<<setprecision(5)<<"|          "<<load_factor[i]<<"        |     "<<linearProbingBeforeDeleteTime[i]<<"ms    |     "<<linearProbingBeforeDeleteProbeCount[i]<<"       |";
    // cout<<fixed<<setprecision(5)<<"     "<<linearProbingAfterDeleteTime[i]<<"ms    |      "<<linearProbingAfterDeleteProbeCount[i]<<"      |"<<endl;
    // cout<<"|__________________________|___________________|____________________|___________________|____________________|"<<endl;
    // }

    // cout<<"\n";
    // cout<<"Table 3: Performance of quadratic probing in various load factors"<<endl;
    // cout<<" ____________________________________________________________________________________________________________"<<endl;
    // cout<<"|                          |             Before Deletion            |              After Deletion            |"<<endl;
    // cout<<"|__________________________|________________________________________|________________________________________|"<<endl;
    // cout<<"|        Load Factor       |  Avg Search Time  |  Avg Num. Of Probe |  Avg Search Time  |  Avg Num. Of Probe |"<<endl;
    // cout<<"|__________________________|___________________|____________________|___________________|____________________|"<<endl;
    // for(i=0;i<loadFactorCount;i++){
    // cout<<fixed<<setprecision(5)<<"|          "<<load_factor[i]<<"        |     "<<quadreticProbingBeforeDeleteTime[i]<<"ms    |     "<<quadreticProbingBeforeDeleteProbeCount[i]<<"       |";
    // cout<<fixed<<setprecision(5)<<"     "<<quadreticProbingAfterDeleteTime[i]<<"ms    |      "<<quadreticProbingAfterDeleteProbeCount[i]<<"      |"<<endl;
    // cout<<"|__________________________|___________________|____________________|___________________|____________________|"<<endl;
    // }

    // cout<<"\n";
    // cout<<"Table 4: Performance of double hashing in various load factors"<<endl;
    // cout<<" ____________________________________________________________________________________________________________"<<endl;
    // cout<<"|                          |             Before Deletion            |              After Deletion            |"<<endl;
    // cout<<"|__________________________|________________________________________|________________________________________|"<<endl;
    // cout<<"|        Load Factor       |  Avg Search Time  |  Avg Num. Of Probe |  Avg Search Time  |  Avg Num. Of Probe |"<<endl;
    // cout<<"|__________________________|___________________|____________________|___________________|____________________|"<<endl;
    // for(i=0;i<loadFactorCount;i++){
    // cout<<fixed<<setprecision(5)<<"|          "<<load_factor[i]<<"        |     "<<doubleHashingBeforeDeleteTime[i]<<"ms    |     "<<doubleHashingBeforeDeleteProbeCount[i]<<"       |";
    // cout<<fixed<<setprecision(5)<<"     "<<doubleHashingAfterDeleteTime[i]<<"ms    |      "<<doubleHashingAfterDeleteProbeCount[i]<<"      |"<<endl;
    // cout<<"|__________________________|___________________|____________________|___________________|____________________|"<<endl;
    // }

    // for(i=0;i<loadFactorCount;i++){
    // cout<<"\n";
    // cout<<"Table "<<i+5<<": Performance of various collision resolution methods in load factor "<<load_factor[i]<<endl;
    // cout<<" ____________________________________________________________________________________________________________"<<endl;
    // cout<<"|                          |             Before Deletion            |              After Deletion            |"<<endl;
    // cout<<"|__________________________|________________________________________|________________________________________|"<<endl;
    // cout<<"|           Method         |  Avg Search Time  |  Avg Num. Of Probe |  Avg Search Time  |  Avg Num. Of Probe |"<<endl;
    // cout<<"|__________________________|___________________|____________________|___________________|____________________|"<<endl;
    // cout<<fixed<<setprecision(5)<<"|     Seperate Chaining    |      "<<schBeforeDeleteTime[i]<<"     |         N/A        |      "<<schAfterDeleteTime[i]<<"     |         N/A        |"<<endl;
    // cout<<"|__________________________|___________________|____________________|___________________|____________________|"<<endl;
    // cout<<fixed<<setprecision(5)<<"|      Linear Probing      |     "<<linearProbingBeforeDeleteTime[i]<<"ms    |     "<<linearProbingBeforeDeleteProbeCount[i]<<"       |";
    // cout<<fixed<<setprecision(5)<<"     "<<linearProbingAfterDeleteTime[i]<<"ms    |      "<<linearProbingAfterDeleteProbeCount[i]<<"      |"<<endl;
    // cout<<"|__________________________|___________________|____________________|___________________|____________________|"<<endl;
    // cout<<fixed<<setprecision(5)<<"|     Quadratic Probing    |     "<<quadreticProbingBeforeDeleteTime[i]<<"ms    |     "<<quadreticProbingBeforeDeleteProbeCount[i]<<"       |";
    // cout<<fixed<<setprecision(5)<<"     "<<quadreticProbingAfterDeleteTime[i]<<"ms    |      "<<quadreticProbingAfterDeleteProbeCount[i]<<"      |"<<endl;
    // cout<<"|__________________________|___________________|____________________|___________________|____________________|"<<endl;
    // cout<<fixed<<setprecision(5)<<"|      Double Hashing      |     "<<doubleHashingBeforeDeleteTime[i]<<"ms    |     "<<doubleHashingBeforeDeleteProbeCount[i]<<"       |";
    // cout<<fixed<<setprecision(5)<<"     "<<doubleHashingAfterDeleteTime[i]<<"ms    |      "<<doubleHashingAfterDeleteProbeCount[i]<<"      |"<<endl;
    // cout<<"|__________________________|___________________|____________________|___________________|____________________|"<<endl;
    // }
}