#include<bits/stdc++.h>
using namespace std;


vector<vector<int>> network(101,vector<int>(101,0)), capacity(101,vector<int>(101,0)), games(101,vector<int>(101,0));
vector<int>win(100), loss(100), matchLeft(100);
map<int, string> names; //For team number to team name correspondence
const int inf=1e9;
int parentsList[100];
vector<bool> visited(100,false);



void print(vector<int> &ans,int x){
    int i,j;
    double total_wins=0,cross_matches=0,count;
    double avg;
    count=ans.size();

    for(i=0;i<ans.size();i++){
        total_wins+=win[ans[i]];
    }

    for(int i=0 ;i<=ans.size() ; i++){
        for(j=i+1;j<ans.size();j++){
            cross_matches+=games[ans[i]][ans[j]];
        }
    }
    
    avg=(total_wins+cross_matches)/count;

    cout<<names[x]<<" is eliminated."<<endl;
    cout<<"They can win at mose "<<win[x]<<"+"<<matchLeft[x]<<"= "<<win[x]+matchLeft[x]<<" games."<<endl;

    for(i=0;i<ans.size();i++){
        cout<<names[ans[i]];
        if(i!=ans.size()-1) cout<<", ";
    }
    cout<<" have won a total of "<<total_wins<<" games."<<endl;
    cout<<"They play each other "<<cross_matches<<" times."<<endl;
    cout<<"So on average, each of the teams in this group wins "<<total_wins+cross_matches<<"/"<<count<<"="<<avg<<" games."<<endl;
    cout<<endl;
    ans.clear();
}


void resetValues(int source, int sink){
    for(int i =source; i<=sink; i++){
        
        visited[i] = false;
        network[i].clear();
    }

    for(int i =source; i<=sink; i++){
        for(int j=source ; j<=sink; j++){
            capacity[i][j]=0;
        }
    }
}


//DFS function to find min cut
void dfs(int x){
    visited[x] = true;
    for(auto temp : network[x])
        {
            if(visited[temp] == false && capacity[x][temp]>0)
                {
                    dfs(temp);
                }
        }
    }   




int bfs(int source, int sink){
    //Initialize all nodes parents to -1 so that we can keep track of who was visited with parents help
    memset(parentsList, -1, sizeof(parentsList)); 

    queue<pair<int,int>> q;
    q.push({source,inf});   //push source to queue
    parentsList[source] = -3;

    while(!q.empty()){
        int currNode = q.front().first;
        int forwardFlow = q.front().second;
        q.pop();


        for(auto x :  network[currNode]){
            if(parentsList[x]==-1 && capacity[currNode][x]!=0){
                parentsList[x] = currNode;
                int p = capacity[currNode][x];
                int temp = min(forwardFlow, p);

                if(x==sink){    //Destination reached so return
                    return temp;
                }

                q.push({x,temp});
            }
        }
    }

    return 0;

}

int edmond_carp(int source, int sink){

    int maxflow=0;
    int temp;

    while(true){
        temp  = bfs(source, sink);

        if(temp==0){    //this means zero flow is possible now from the source to the sink, thus we terminate the algorithm
            break;
        }

        maxflow +=  temp;

        int currNode = sink;

        while(currNode!=source){    //Backtracking
            int prevNode = parentsList[currNode];
            capacity[currNode][prevNode]  += temp;
            capacity[prevNode][currNode]  -= temp;
            currNode = prevNode;
        }

    }

    return maxflow;

}

int main(){
    freopen("input.txt","r",stdin);
    freopen("out.txt","w",stdout);

    
    int teamCount,temp, source, sink;
    string s;
    vector<int> ans;
    
    cin>>teamCount;
    source =0 ;
    sink = 50;

    //Taking inputs
    for(int i =1; i<=teamCount ; i++){
        cin>>s>>win[i]>>loss[i]>>matchLeft[i];
        names[i] = s;

        for(int j = 1; j <= teamCount; j++){
            cin>> temp;
            games[i][j] = temp;
        }

    }


    for(int k =1; k<=teamCount; k++){
        int expectedFlow = 0;

        //Forming the network
        for(int i = 1; i<teamCount; i++){

            for(int j=i+1; j<=teamCount; j++){

                if(i!=k && j!=k)
                {
                    int node = ( i*(teamCount) ) + j ;

                    //Source to game node
                    network[source].push_back(node);
                    network[node].push_back(source);

                    //Game node to team node
                    network[node].push_back(i);
                    network[node].push_back(j);
                    network[i].push_back(node);
                    network[j].push_back(node);

                    //source to game nodes capacity
                    capacity[source][node] = games[i][j];
                    capacity[node][i] = inf;
                    capacity[node][j] = inf;

                    //Needed flow for a team to qualify
                    expectedFlow += games[i][j]; 
                }
            }
        }

        for(int m =1; m<=teamCount; m++){

            if(m!=k)
            {
                //team nodes to sink node 
                network[m].push_back(sink);
                network[sink].push_back(m);
            
                capacity[m][sink] = win[k] + matchLeft[k] - win[m];

                //These teams are the reason k is getting eliminated
                if(capacity[m][sink]<0){
                    ans.push_back(m);
                }
            }
        }

        if(ans.size()!=0){
            print(ans, k);
            resetValues(source,sink);
            continue;
        }
        
        int maxflow = edmond_carp(source, sink);

        //Meaning flow is less than expected which means that all the game nodes haven't been saturated
        if(expectedFlow!= maxflow){
            dfs(source);    //finding min cut
            for(int m =1; m<= teamCount ;m++){
                if(visited[m]==true){
                    ans.push_back(m);
                }
            }

            print(ans, k);
        }
        resetValues(source, sink);




    }
    cout<<endl;
    
}