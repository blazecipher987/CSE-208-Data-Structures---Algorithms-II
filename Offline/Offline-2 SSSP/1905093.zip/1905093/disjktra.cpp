#include<bits/stdc++.h>
using namespace std;

int const n = 10000;
int const inf = 1e9+10;

vector<pair<int,int>> adj[n];
vector<int> dist(n,inf);
int parent[n];


void backTrack_path(int destination){

    int j = destination;
        vector<int> temp;

        while(parent[j]!=-1){
            temp.push_back( parent[j]);
            j = parent[j];
        }

        reverse(temp.begin(),temp.end());

            while(!temp.empty()){
            cout<<temp.front()<<" -> ";
            temp.erase(temp.begin());
        }
        cout<<destination<<endl;

}


//Time Complexity O(ElogV)
void dijkstra(int source, int destination){
    
    vector<int> visited(n,0);

    set<pair<int,int>> st;  //Set used for keeping track of smallest element

    st.insert({0,source});
    dist[source]=0;
    parent[source] = -1;

    while(st.size() >0){
        auto temp = *st.begin(); //extract element from the set
        int v = temp.second;
        int w = temp.first;
        st.erase(st.begin());

        if(visited[v]==1)
            continue;
        visited[v] = 1;

        for(auto child : adj[v]){
            int child_v = child.second;
            int child_w = child.first;

            if(dist[v]+ child_w <  dist[child_v]){
                dist[child_v] = dist[v] + child_w;
                parent[child_v]= v ;
                st.insert({dist[child_v] , child_v});
            }
            
        }

    }

    cout<<"Shortest Path Cost: "<<dist[destination]<<endl;
   
    backTrack_path(destination);

}


int main(){

    freopen("input_disjktra.txt","r",stdin);
    freopen("output.txt","w",stdout);
    int t=1;

    while(t>0){
        int edges, nodes , source, destination;
    cin>>nodes>>edges;

    for(int i = 0 ;i<edges ; i++){
        int x, y, weight;
        cin>>x>>y>>weight;
        adj[x].push_back({weight,y});
    }
    cin>>source>>destination;

    dijkstra(source, destination);

    t--;
    }

    
    
}