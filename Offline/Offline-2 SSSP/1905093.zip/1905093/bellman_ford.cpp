#include<bits/stdc++.h>
using namespace std;

int const n = 10000;
int const inf = 1e9+10;

vector<pair<int, pair<int, int>>> adj;
vector<int> dist(n,inf);
int parent[n];
int child[n];

void backTrack_path(int destination){

    int j = destination;
        vector<int> temp;

        //Reversing the array
        while(parent[j]!=-1){
            temp.push_back( parent[j]);
            j = parent[j];
        }

        reverse(temp.begin(),temp.end());

            while(!temp.empty()){
            cout<<temp.front()<<" -> ";
            temp.erase(temp.begin());
        }
        cout<<destination<<endl;

}

//Time Complexity: O(V.E)
void bellman_ford(int source, int nodes, int destination){
    vector<int> dist ( n, inf);
    dist[source] = 0;   //Distance from self is zero
    parent[source] = -1; //Source has no parents
    bool flag=false;    //Flag for dectecting neg cycle in graph

    for (int i =0;  i< nodes-1; i++){ // (V-1) times
        for(auto temp : adj){   //traverses through all the edges so E times

            int weight  = temp.first;
            int u = temp.second.first;
            int v = temp.second.second;

            if(dist[u] + weight < dist[v]){
                parent[v] =  u;
                dist[v] = dist[u] + weight;
            }
            
        }
    }

    //One more relaxation to see if the given graph has a negative cycle
    //Because once n-1 relaxations have been done, the graph should not change even with further relaxations
    for(auto temp : adj){
        int weight  = temp.first;
        int u = temp.second.first;
        int v = temp.second.second;

         if(dist[u] + weight < dist[v]){
                flag = true;
                break;
            }

    }

    if(flag){
        cout<<"The graph contains a Negative Cycle"<<endl;
    }
    else{
        cout<<"The graph does not contain a negative cycle"<<endl;
        cout<<"Distance between soucee and destination is: "<< dist[destination]<<endl;

        backTrack_path(destination);

    }


}


int main(){

    freopen("input_bellman.txt","r",stdin);
    freopen("output.txt","w",stdout);


    int edges,nodes, source, destination;
    cin>>nodes>>edges;
    for(int i= 0; i<edges ; i++){
        int x, y ,w;
        cin>>x>>y>>w;
        adj.push_back({w,{x,y}});
    }
    cin>>source>>destination;

    bellman_ford(source,nodes,destination);
}