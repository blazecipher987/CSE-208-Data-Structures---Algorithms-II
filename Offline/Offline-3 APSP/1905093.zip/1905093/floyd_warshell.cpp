#include<bits/stdc++.h>
using namespace std;

int const n = 1000;
int const inf = 1e9;

vector<pair<int, pair<int, int>>> adj;
int dist[n][n] ;
vector<vector<int>> graph2(101,vector<int>(101,inf)), mm;
int graph1[n][n];
//int graph2[n][n];
int parent[n];
int child[n];

int temp1[n][n];


//RUNTIME OF FLOYD WARSHALL n^3;
void floyd_warshell(int nodes){ 

    for(int k=1 ; k<=nodes; k++){      //FOR EACH LEVEL OF VBRTICE
        for(int i=1; i<=nodes; i++){
            for(int j=1; j<=nodes; j++){
                graph1[i][j] = min(graph1[i][j] , graph1[i][k] + graph1[k][j]);
            }
        }
    }
}

void print_warshell(int nodes){
    for(int i=1 ; i<=nodes; i++){
        for(int j = 1; j<=nodes; j++){
            if(graph1[i][j]==inf){
                cout<<setw(10)<<"Inf";
            }
            else
                cout<<setw(10)<<graph1[i][j];
        }
        cout<<endl;
    }
}


//RUNTIME OF APSP USING MATRIX MULTIPLICATION IS n^3(logn)
vector<vector<int>> extend_shortest_path(const vector<vector<int>> &temp, int nodes){

    vector<vector<int>> x(nodes+1, vector<int>(nodes+1,1e9));

    for(int i= 1; i<=nodes; i++){   //THIS PART IS n^3
        for(int j=1; j<= nodes; j++){
            for(int k=1; k<=nodes; k++){
                
                x[i][j] = min(x[i][j] , temp[i][k] + temp[k][j]);
            }
        }
    }

    return x;
}

vector<vector<int>> matrix_multiplication(const vector<vector<int>> &temp, int nodes){
    int m=1;
    vector<vector<int>> l ;
    l= temp;
    
    while(m <nodes-1){      //THis part is logn
        l = extend_shortest_path(l,nodes);
        m =2*m;
    }

    return l;
}




void print_mm(vector<vector<int>> &graph2, int nodes){
    for(int i=1 ; i<=nodes; i++){
        for(int j = 1; j<=nodes; j++){
            if(graph2[i][j]==inf){
                cout<<setw(10)<< "Inf";
            }
            else
                cout<<setw(10)<<graph2[i][j];

        }
        cout<<endl;
    }
}


int main(){

    freopen("input_floyd.txt","r",stdin);
    freopen("output.txt","w",stdout);

     for(int i = 0 ;i< 100 ;i++){
        for(int j =0; j< 100 ; j++){
            if(i==j)
               {
                    graph1[i][j]=0;
                    graph2[i][j]=0;
                }
            else
                {
                    graph1[i][j] = inf;
                    graph2[i][j] = inf;
                }
        }
    }

    int x,y,w,nodes, edges;
    cin>>nodes>>edges;

    for(int i=0; i<edges; i++){
        cin>>x>>y>>w;
        graph1[x][y]=w;
        graph2[x][y]=w;
    }
    
    

    // floyd_warshell(nodes);
    // print_warshell(nodes);
    
    mm = matrix_multiplication(graph2,nodes);
    print_mm(mm,nodes);

    

}