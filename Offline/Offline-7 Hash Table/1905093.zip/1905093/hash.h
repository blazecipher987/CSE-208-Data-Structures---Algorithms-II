#include <bits/stdc++.h>
using namespace std;


vector<long long int> p(10);
void powerCalculation(){
    p[0]=1;
    for(long long int i=1;i<10;i++){
        p[i]=p[i-1]*31;
    }  
}

// Random Unique String Generation
vector<string> randomStringGenerator(long long int n)
{
    srand(time(0));
    string s;
    long long int sz = 0;
    vector<string> v(n);
    map<string, long long int> mp;

    while (sz != n)
    {
        s = "";
        for (long long int i = 0; i < 7; i++)
        {
            s += ('a' + rand() % 26);
        }
        if (mp[s] == 0)
        {
            v[sz] = s;
            mp[s]++;
            sz++;
        }
    }
    return v;
}



// Hash functions taken from internet literature
// djb2 Hash Function
long long int hashFunction1(long long int n, string s)
{
    long long int hash = 5381, i;
    for (i = 0; i < s.size(); i++)
    {
        hash = ((hash << 5) + hash) + s[i]; // hash *33 +s[i] , bit shifts are used for faster multiplication
    }
    return (hash % (n - 1)) + 1;
}

// sbms function
long long int hashFunction2(long long int n, string s){
    long long int hash=0,i;
    for(i=0;i<s.size();i++){
        hash+=s[i]*p[i];
    }
    return hash%n;
}

void findCount(int probe){
    if(probe>100){
        cout<<"The probe has crossed the 100 mark"<<endl;
    }
    else{
         cout<<"Still under 100"<<endl;
    }
}

// Check Unique Hash Value For Hash Function 1
long long int checkUniqueHash1(const vector<string> &v, long long int n)
{
    long long int hash;
    set<long long int> st; // to avoid repetations
    for (int i = 0; i < v.size(); i++)
    {
        hash = hashFunction1(n, v[i]);
        st.insert(hash);
    }
    return st.size();
}

// Check Unique Hash Value For Hash Function 2
long long int checkUniqueHash2(const vector<string> &v, long long int n)
{
    long long int hash;
    set<long long int> st;
    for (int i = 0; i < v.size(); i++)
    {
        hash = hashFunction2(n, v[i]);
        st.insert(hash);
    }
    return st.size();
}

void checkHashUniqueValues(const vector<string> &v, long long n)
{
    cout <<"Number of unique values for hash function 1 is: "<< checkUniqueHash1(v, n) << endl;
    cout <<"Number of unique values for hash function 2 is: "<< checkUniqueHash2(v, n) << endl;
}


// For Closed Addressing ( chain addressing)
struct node
{
    node *next = NULL; // Link to next element in list
    string key;
    long long int value;
};

// For Open Addressing (no side chain, array size max elements fixed to n)
struct node2
{
    string key = "";
    long long int value;
    bool isEmpty = true;
    bool isDeleted = false;
};

// Seperate Chaining
class seperateChainHashing
{
private:
    node *hashTable;
    long long int n = 0; // length of hash table

public:
    seperateChainHashing()
    {
        
    }

    // Initialize The Hash Table with Given Size || Be Sure To Clear The Hash Table Before Re-Initializing
    void initialize(long long int sz)
    {
        n = sz;
        hashTable = new node[n];
    }

    void insert(string s, long long int val)
    {
        long long int hash = (hashFunction1(n,s) % n);
        node *temp, *ptr;
        temp = new node;

        temp->key = s;
        temp->value = val;
        temp->next = NULL;

        ptr = (hashTable + hash);  //travel along the hash table to the designated position

        //Rearrange values in a sorted order
        while (ptr->next != NULL)
        {
            if (val >= ptr->value && val <= ptr->next->value)
            {
                temp->next = ptr->next->next;
                ptr->next = temp;
                break;
            }
            ptr = ptr->next;
        }

        if (ptr->next == NULL)
        {
            ptr->next = temp;
        }
    }

    long long int search(string s)
    {
        long long int hash = hashFunction1(n,s);
        long long int pos = 0;
        node *temp = (hashTable + hash);
        temp = temp->next;

        while (temp != NULL)
        {
            if (temp->key == s)
            {
                pos = temp->value;
                break;
            }
            temp = temp->next;
        }
        return pos;
    }

    long long int removee(string s)
    {
        long long int hash = hashFunction1(n, s);
        long long int pos = 0;
        node *temp = (hashTable + hash), *prev;
        prev = temp;
        temp = temp->next;

        while (temp != NULL)
        {
            if (temp->key == s)
            {
                prev->next = temp->next;
                pos = temp->value;
                delete temp;
                break;
            }
            prev = temp;
            temp = temp->next;
        }

        return pos;
    }

    void clear()
    {
        node *temp, *ptr;
        for (long long int i = 0; i < n; i++)
        {
            temp = (hashTable + i);
            temp = temp->next;
            while (temp != NULL)
            {
                ptr = temp;
                temp = temp->next;
                delete ptr;
            }
        }
        delete[] hashTable;
        n = 0;
    }

    void print()
    {
        node *temp;
        for (long long int i = 0; i < n; i++)
        {
            temp = (hashTable + i);
            temp = temp->next;

            cout << i << "---->";
            while (temp != NULL)
            {
                cout << "(" << temp->key << " " << temp->value << ") ";
                temp = temp->next;
            }
            cout << endl;
        }
    }
};

// Linear Probing
class linearProbing
{
private:
    node2 *hashTable;
    long long int n = 0; // length of hash table

public:
    linearProbing()
    {
        
    }

    void initialize(long long int sz)
    {
        
        n = sz;
        hashTable = new node2[n];
    }

    pair<long long int, long long int> insert(string str, long long int val)
    {
        long long int hash, probValue = 0, value = 0;
        hash = hashFunction1(n, str);
        for (long long int i = 0; i < n; i++)
        {
            probValue = i+1;
            if ((hashTable + (hash + i) % n)->isEmpty == true) //Only isnert the positon is found to be empty and not a deleted one
            {
                (hashTable + (hash + i) % n)->key = str;
                (hashTable + (hash + i) % n)->value = val;
                (hashTable + (hash + i) % n)->isEmpty = false;
                (hashTable + (hash + i) % n)->isDeleted = false;
                value = val;
                break;
            }
        }
        return make_pair(value, probValue);
    }

    pair<long long int, long long int> search(string str)
    {
        long long int hashedValue, probValue = 0;
        long long data_Position=0;
        hashedValue = hashFunction1(n,str);    //The hash value returned by the function

        for (long long int i = 0; i < n; i++)
        {
            node2 *temp = temp;
            probValue = i+1;
            if (temp && (temp->isDeleted == false))
            {
                break;  //This means there was never a value corresponding to this index and thus the result is false in searching
            }
            else if (temp->key == str)    //This mean that the hashed values are either found to be full or fall among deleted nodes
            {
                data_Position = temp->value;
                break;
            }
        }
        return make_pair(data_Position, probValue);
    }

    // p.first --> value ,p.second --> number of probs
    pair<long long int, long long int> removee(string str)
    {
        long long int hash, probValue = 0, data_Position = 0;
        hash = hashFunction1(n,str);

        for (long long int i = 0; i < n; i++)
        {
            node2 *temp = (hashTable + (hash + i) % n);
            probValue = i+1;
            if (temp->isEmpty == false && (hashTable + (hash + i) % n)->key == str)
            {
                data_Position = temp->value;   //get data value from that position

                temp->isDeleted = true;    //data gets deleted and it also becomes empty
                temp->isEmpty = true;
                break;
            }
        }
        
        return make_pair(data_Position, probValue);
    }

    void clear()
    {
        delete[] hashTable;
        n = 0;
    }

    void print()
    {
        for (long long int i = 0; i < n; i++)
        {
            cout << i << "--> ";

            if ((hashTable + i)->isEmpty == false)
            {
                cout << "(" << (hashTable + i)->key << " " << (hashTable + i)->value << ")";
            }
            cout << endl;
        }
    }
};

// Quadratic Probing
class quadraticProbing
{
private:
    node2 *hashTable;
    long long int n = 0; // length of hash table
    long long int c1 = 31;
    long long int c2 = 37;

public:
    quadraticProbing()
    {
     
    }

    // Initialize The Hash Table with Given Size || Be Sure To Clear The Hash Table Before Re-Initializing
    void initialize(long long int sizee)
    {
        n = sizee;
        hashTable = new node2[n];
    }

    pair<long long int, long long int> insert(string str, long long int val)
    {
        long long int hash, probValue = 0, res = 0;
        hash = hashFunction1(n,str);
        for (long long int i = 0; i < n; i++)
        {
            node2* temp = (hashTable + (hash + c1 * i + c2 * i * i) % n);
            probValue = i+1;
            if (temp->isEmpty == true)
            {
                temp->key = str;
                temp->value = val;
                temp->isEmpty = false;
                temp->isDeleted = false;
                res = val;
                break;
            }
        }
        return make_pair(res, probValue);
    }

    // p.first --> value ,p.second --> number of probs
    pair<long long int, long long int> search(string str)
    {
        long long int hash, probValue = 0, res = 0;
        hash = hashFunction1(n,str);

        for (int i = 0; i < n; i++)
        {
            node2* temp = (hashTable + (hash + c1 * i + c2 * i * i) % n);
            probValue= i+1;
            if (temp->isEmpty == true)
            {
                if (temp->isDeleted == false)
                    break;
            }
            else if (temp->key == str)
            {
                res = temp->value;
                break;
            }
        }

        return make_pair(res, probValue);
    }

    // p.first --> value ,p.second --> number of probs
    pair<long long int, long long int> removee(string str)
    {
        long long int hash, probValue = 0, res = 0, i;
        hash = hashFunction1(n, str);

        for (i = 0; i < n; i++)
        {
            node2* temp = (hashTable + (hash + c1 * i + c2 * i * i) % n);
            probValue= i+1;
            if (temp->isEmpty == false && temp->key == str)
            {
                res = temp->value;

                temp->isDeleted = true;
                temp->isEmpty = true;
                break;
            }
        }
        return make_pair(res, probValue);
    }

    void clear()
    {
        delete[] hashTable;
        n = 0;
    }

    void print()
    {
        for (long long int i = 0; i < n; i++)
        {
            cout << i << "--> ";

            if ((hashTable + i)->isEmpty == false)
            {
                cout << "(" << (hashTable + i)->key << " " << (hashTable + i)->value << ")";
            }
            cout << endl;
        }
    }
};

// Double Hashing
class doubleHashing
{
private:
    node2 *hashTable;
    long long int n = 0; // length of hash table

public:
    doubleHashing()
    {
       
    }

    // Initialize The Hash Table with Given Size || Be Sure To Clear The Hash Table Before Re-Initializing
    void initialize(long long int sz)
    {
        n = sz;
        hashTable = new node2[n];
    }

    pair<long long int, long long int> insert(string str, long long int val)
    {
        long long int hashValue1, hashValue2, prob = 0, res = 0;
        hashValue1 = hashFunction1(n, str);//polymial hashing using the power of 31st's
        hashValue2 = hashFunction2(n, str);//dbj2 hashing which returns a values smller than n

        for (long long int i = 0; i < n; i++)
        {
            prob++;
            if ((hashTable + (hashValue1 + i * hashValue2) % n)->isEmpty == true)    //we divide with n to mod the number and kee t winthin the vayes of our hash table
            {
                (hashTable + (hashValue1 + i * hashValue2) % n)->key = str;
                (hashTable + (hashValue1 + i * hashValue2) % n)->value = val;
                (hashTable + (hashValue1 + i * hashValue2) % n)->isDeleted = false;
                (hashTable + (hashValue1 + i * hashValue2) % n)->isEmpty = false;
                res = val;
                break;
            }
        }
        return make_pair(res, prob);
    }

    // p.first --> value ,p.second --> number of probs
    pair<long long int, long long int> search(string str)
    {
        long long int hashValue1, hashValue2, i, prob = 0, res;
        hashValue1 = hashFunction1(n, str);
        hashValue2 = hashFunction2(n, str);

        for (i = 0; i < n; i++)
        {
            prob++;
            if ((hashTable + (hashValue1 + i * hashValue2) % n)->isEmpty == true)
            {
                if ((hashTable + (hashValue1 + i * hashValue2) % n)->isDeleted == false)
                    break;
            }
            else if ((hashTable + (hashValue1 + i * hashValue2) % n)->key == str)
            {
                res = (hashTable + (hashValue1 + i * hashValue2) % n)->value;
                break;
            }
        }
        return make_pair(res, prob);
    }

    // p.first --> value ,p.second --> number of probs
    pair<long long int, long long int> removee(string str)
    {
        long long int hashValue1, hashValue2, i, prob = 0, res;
        hashValue1 = hashFunction1(n, str);
        hashValue2 = hashFunction2(n,str);

        for (i = 0; i < n; i++)
        {
            prob++;
            if ((hashTable + (hashValue1 + i * hashValue2) % n)->isEmpty == false && (hashTable + (hashValue1 + i * hashValue2) % n)->key == str)
            {
                res = (hashTable + (hashValue1 + i * hashValue2) % n)->value;

                (hashTable + (hashValue1 + i * hashValue2) % n)->isDeleted = true;
                (hashTable + (hashValue1 + i * hashValue2) % n)->isEmpty = true;
                break;
            }
        }
        return make_pair(res, prob);
    }

    void clear()
    {
        delete[] hashTable;
        n = 0;
    }

    void print()
    {
        for (long long int i = 0; i < n; i++)
        {
            cout << i << "--> ";

            if ((hashTable + i)->isEmpty == false)
            {
                cout << "(" << (hashTable + i)->key << " " << (hashTable + i)->value << ")";
            }
            cout << endl;
        }
    }
};

void callObjects(){
    seperateChainHashing seperateChainHashing;
    linearProbing linearProbing;
    quadraticProbing quadraticProbing;
    doubleHashing doubleHashing;
}