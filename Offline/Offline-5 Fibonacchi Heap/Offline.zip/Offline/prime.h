#include<bits/stdc++.h>
using namespace std;

struct Node
{

	int key; 
    pair<int,int> p;
	Node* parent;
	Node* child;
	Node* left;
	Node* right;
	int degree;
	bool mark;

};

		
class FibHeap {
public:
	Node* mainHeap;	//Main node which stores the whole heap
	int count;			//Count of nodes in the heap

	FibHeap(){  // initialize a new and empty Fib Heap
		mainHeap = nullptr;
		count = 0;
	}

	~FibHeap() {
		clear(mainHeap);
	}

	//Return a new node containing the newPair value as well
	Node* insert(pair<int,int> newPair);

	// Return the Pair of the minimum first element node 				
	pair<int,int> extract_min(); 

	// Return the current node count of the heap
	bool empty();


private:
	
	Node* createNodeUtil(pair<int,int> newPair);
	void deleteNodeFromRootlist(Node* x);
    void merge(FibHeap &temp);
	Node* mergeUtil(Node* x, Node* y);
	void linkAsChild(Node *child, Node *parent);
	void Consolidate();
	void unlinkParent(Node* x);
	Node* extractMinUtil();
	void clear(Node* x);
	

};



void FibHeap::merge(FibHeap &another)
{
	mainHeap = mergeUtil(mainHeap, another.mainHeap);
	count += another.count;
	another.mainHeap = nullptr; // so that another 
	another.count = 0;
}

pair<int,int>  FibHeap::extract_min()
{
	Node* minNode = extractMinUtil();
	pair<int,int> ret = minNode->p;
    //cout<<ret.first<<endl;
	delete minNode;
	return ret;
}

bool FibHeap::empty(){
	if(count!=0){
		return false;
	}
	return true;
}

Node* FibHeap::insert(pair<int,int> newPair)	//Runtime O(1)
{
	Node* newNode = createNodeUtil(newPair);
	mainHeap = mergeUtil( mainHeap, newNode);
	count++;
	return newNode;
}



Node* FibHeap::createNodeUtil(pair<int,int> temp)	//Runtime O(1)
{
    
    
	Node* newNode = new Node;
	int newPair = temp.first;
    newNode->p = temp;
	newNode->key = newPair;
	newNode->left = newNode;
	newNode->right = newNode;
	newNode->parent = nullptr;
	newNode->child = nullptr;
	newNode->degree = 0;
	newNode->mark = false;
	return newNode;
}


Node* FibHeap::mergeUtil(Node* node1, Node* node2)	//Runtime O(1)
{
	if(node1 == nullptr)
		return node2;
	else if(node2 == nullptr)	
		return node2;

	if( node2->key < node1->key ) // Always assign node1 with the smaller node
	{
		Node* temp = node1;
		node1 = node2;
		node2 = temp;
	}

	Node* aRight = node1->right;
	Node* bLeft	= node2->left;
	node1->right = node2;
	node2->left = node1;
	aRight->left = bLeft;
	bLeft->right = aRight;
	return node1;	
}


void FibHeap::deleteNodeFromRootlist(Node* x)	//Runtime O(1)
{
	//Signle node,thus deleting it leaves nothing to return
    if (x->right == x)
        return;

    Node* leftSib = x->left;
    Node* rightSib = x->right;
    leftSib->right = rightSib;
    rightSib->left = leftSib;
    x->left = x->right = x;

}



Node* FibHeap::extractMinUtil()
{
	Node* mn = mainHeap;

	//If heap is null return null pointer
    if (mn == nullptr){
        return nullptr;
    }


    unlinkParent(mn->child);	//Remove the parent pointer from all the child nodes of the minimum element
    mergeUtil(mn, mn->child);	//Merge the childs of min node with the rootlist, thus now the childs become siblings of min node


    if (mn == mn->right){
        mainHeap = nullptr;	//Means the min node was the only element of the FibHeap, thus removing it gives us a null heap
    }
	else{
        mainHeap = mn->right;	
    }

    deleteNodeFromRootlist(mn);	//Seperate the min node form the rest of the rootlist
    if (mainHeap != nullptr){
        Consolidate();	//Rearrange the heap
    }
    count--;
    return mn;
}

/*make all nodes' parent nullptr in a circular list*/
void FibHeap::unlinkParent(Node* x)	
{
	if(x == nullptr)
		return;
	Node* y = x;
	do {
		y->parent = nullptr;
		y = y->right;
	}while(y != x);
}


void FibHeap::Consolidate()
{
    int Dn;
	Dn = (int)(log2(count) / log2(1.618));
    Node** A = new Node*[Dn + 1];	//An array of nodes to keep track of the child degree
    for(int i = 0; i < Dn + 1; i++){
        A[i] = nullptr;
    }

    vector<Node*> v;
    auto node = mainHeap;
	//Add all the rootlist nodes to the v
    do{
        v.emplace_back(node);
        node = node->right;
    } while (node != mainHeap);

    for (auto ptr: v){
        int d = ptr->degree;
        deleteNodeFromRootlist(ptr);	//First we disconnect the node from the rootlist
        while(A[d] != nullptr){
			//Ensure the parent has the min value
            auto tmp = A[d];
            if (ptr->key > tmp->key){
                swap(ptr, tmp);
            }
            linkAsChild(tmp, ptr);	// Make temp a child of ptr,hence increasing the dergee of the parent
            A[d++] = nullptr;
        }

        A[ptr->degree] = ptr;	//Keep a track of the pointer to that node for future mergeing
        mainHeap = ptr;
    }


	//Now link back all the remaining nodes in the A[] again and form the new rootlist
    for (int i = 0; i < Dn + 1; i++){
        if (A[i] != nullptr){
			if(A[i] != mainHeap){
				 mergeUtil(mainHeap, A[i]);
			}
           
        }
    }


	//Determine the new min node of the rootlist
    Node* m = mainHeap;
    Node* n = m;
    do{
        if (n->key < mainHeap->key){
            mainHeap = n;
        }
        n = n->right;
    } while (n != m);


    delete []A;		//Release memory
}


//Self explanatory
void FibHeap::linkAsChild(Node *child, Node *parent)	//Runtime O(1)
{
    child->parent = parent;
    parent->child = mergeUtil(parent->child, child);
    parent->degree++;
    child->mark = false;
}



void FibHeap::clear(Node* x)
{
	if (x==nullptr)
		return; 

	Node* temp = x;  

	do{
		Node* a = temp; 
		temp = temp->right;
		clear(a->child);
		delete a;
	} while(temp != x); 
	
}



// int main(){

//     FibHeap *temp = new FibHeap();

//     temp->insert({10,4});
//     temp->insert({3,1});
//     temp->insert({2,10});
//     temp->insert({5,34});

//     pair<int,int> t;
//     t = temp->extract_min();
//     cout<<t.first<<endl;

//    t = temp->extract_min();
//    cout<<t.first<<endl;

//    t = temp->extract_min();
//    cout<<t.first<<endl;

// }
