#include <bits/stdc++.h>
#include <chrono>
#include "heap.h"
#include "prime.h"
using namespace std;
using namespace chrono;

int const n = 10000;
int const inf = 1e9 + 10;
int cost;

vector<pair<int, int>> adj[n];
vector<int> dist(n, inf);
int parent[n];
int vertex_cost[n];



void backTrack_path(int destination, int &ans)
{

    int j = destination;
    vector<int> temp;

    while (parent[j] != -1)
    {
        temp.push_back(parent[j]);
        ans++;
        j = parent[j];
        cost += vertex_cost[j];
    }

    reverse(temp.begin(), temp.end());

    while (!temp.empty())
    {
        // cout<<temp.front()<<" -> ";
        temp.erase(temp.begin());
    }
    cost += vertex_cost[destination];
    // cout<<destination<<endl;
}

void dijkstra(int source, int destination)
{

    vector<bool> visited(n, 0);

    FibHeap *q = new FibHeap();

    q->insert({0, source});

    dist[source] = 0;
    parent[source] = -1;

    while (!q->empty())
    {

        pair<int, int> temp = q->extract_min();
        int w = temp.first;
        int u = temp.second;

        if (visited[u] == true)
            continue;
        visited[u] = true;

        for (pair<int, int> v : adj[u])
        {
            // cout<<u<<" "<<v.first<<" "<<v.second;
            // cout<<endl;
            int child_u = v.second;
            int child_w = v.first;

            if (dist[u] + child_w < dist[child_u])
            {
                dist[child_u] = dist[u] + child_w;
                parent[child_u] = u;
                q->insert({dist[child_u], child_u});
            }
        }
    }

    // cout<<"Shortest Path Cost: "<<dist[destination] <<endl;
    //  int ans = 0;
    //  backTrack_path(destination, ans);
    //  cout<<ans<<"    "<<dist[destination];
}

void binayHeap(int source, int destination)
{

    vector<bool> visited(n, 0);

    Heap *q = new Heap(20);

    q->insert({0, source});

    dist[source] = 0;
    parent[source] = -1;

    while (q->size() != 0)
    {

        pair<int, int> temp = q->extract_min();
        int w = temp.first;
        int u = temp.second;

        if (visited[u] == true)
            continue;
        visited[u] = true;

        for (pair<int, int> v : adj[u])
        {
            int child_u = v.second;
            int child_w = v.first;

            if (dist[u] + child_w < dist[child_u])
            {
                dist[child_u] = dist[u] + child_w;
                parent[child_u] = u;
                q->insert({dist[child_u], child_u});
            }
        }
    }

    // cout<<"Shortest Path Cost: "<<dist[destination]<<endl;
    int ans = 0;
    backTrack_path(destination, ans);
    cout << ans << "    " << dist[destination] << "     ";
}

void original(int source, int destination)
{

    vector<int> visited(n, 0);

    set<pair<int, int>> st; // Set used for keeping track of smallest element

    st.insert({0, source});
    dist[source] = 0;
    parent[source] = -1;

    while (st.size() > 0)
    {
        auto temp = *st.begin(); // extract element from the set
        int v = temp.second;
        int w = temp.first;
        st.erase(st.begin());

        if (visited[v] == 1)
            continue;
        visited[v] = 1;

        for (auto child : adj[v])
        {
            int child_v = child.second;
            int child_w = child.first;

            if (dist[v] + child_w < dist[child_v])
            {
                dist[child_v] = dist[v] + child_w;
                parent[child_v] = v;
                st.insert({dist[child_v], child_v});
            }
        }
    }

    cout << "Shortest Path Cost: " << dist[destination] << endl;

    backTrack_path(destination, cost);
}

int main()
{

    freopen("input1.txt", "r", stdin);
    freopen("output.txt", "w",stdout);
    int t = 1;

    {
        int edges, nodes, source, destination;
        source= 0, destination =4;
        cin >> edges >> nodes;

        for (int i = 0; i < edges; i++)
        {
            int x, y, weight;
            cin >> x >> y >> weight;
            adj[x].push_back({weight, y});
            adj[y].push_back({weight, x});
        }

        //fclose(stdin);

        freopen("input2.txt", "r", stdin);
        cin >> t;


        while (t > 0)

        {
            
            cin >> source >> destination;

            auto time_start1 = high_resolution_clock::now();
            binayHeap(source, destination);
            auto time_end1 = high_resolution_clock::now();

            int temp1 = duration_cast<nanoseconds>(time_end1 - time_start1).count();

            auto time_start = high_resolution_clock::now();
            dijkstra(source, destination);
            auto time_end = high_resolution_clock::now();

            int temp2 = duration_cast<nanoseconds>(time_end - time_start).count();

            cout << temp1 << "   " << temp2 << endl;

            t--;
        }


    }
}