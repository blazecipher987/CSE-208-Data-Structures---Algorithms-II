#include<bits/stdc++.h>


using namespace std;

class Heap{
    private:
        int *ar;
        pair<int,int> *p;
        int maxSize;
        int currElement;


    public:
        Heap(int sizee)
        {
            maxSize = sizee+1; //since we are beginning our elements from index 1
            currElement = 0; //heap currently has space allocated but no elements
            ar = new int[maxSize];
            p = new pair<int,int> [maxSize];
        }

        // Heap(vector<int>&v)
        // {
        //     maxSize = v.size() +1;
        //     ar = new int[maxSize];
        //     for(int i = 0; i<v.size() ; i++){
        //         ar[i+1] = v[i];
        //     }
        //     currElement = v.size();

        //     buidMaxHeap();
        // }

        ~Heap()
        {
            delete [] ar;
            delete [] p;
        }

        void maxHeapify(int i)
        {
            int parent = i;
            int left = 2*i ;
            int right = 2*i +1;
            int largest = i; //keeps track of the index of the max element among the parent and children

            if(left<=currElement && ar[left] < ar[i]){ //checks if left child is present and if it is bigger than parent
                largest = left;
            }
            if(right<=currElement && ar[right] < ar[largest]){ //checks if right child is present and if it is bigger than current largest
                largest = right;
            }

            if(largest!= i){ //swap parent with the larger child if that is the case
                swap(ar[i], ar[largest]);
                swap(p[i], p[largest]);
                maxHeapify(largest);

            }
        }

        void buidMaxHeap()
        {
            for(int i= currElement/2 ; i>=1 ; i--){ //since leafs already maintain the heap property
                maxHeapify(i);
            }
        }

        void insert(pair<int,int> x)
        {
            if(currElement<maxSize)
            {

                currElement++;
                ar[currElement]=x.first;
                p[currElement] = x;

                int pos=currElement;

                while(ar[pos]<ar[pos/2] && pos/2>=1){//If parent is smaller than the child,swap
                    swap(ar[pos],ar[pos/2]);
                    swap(p[pos], p[pos/2]);
                    pos/=2; //check another node
                }
            }

            else{
                int *temp;
                pair<int,int> *temp2;
                temp = new int[maxSize*2];
                temp2 = new pair<int,int>[maxSize*2];
                int s = maxSize;
                maxSize = maxSize*2;

                for(int i = 1; i<s; i++){
                    temp[i] = ar[i];
                }

                ar = new int[maxSize];
                for(int i =1; i<s ; i++){
                    ar[i] = temp[i];
                }

                for(int i = 1; i<s; i++){
                    temp2[i] = p[i];
                }

                p = new pair<int,int>[maxSize];
                for(int i =1; i<s ; i++){
                    p[i] = temp2[i];
                }

                currElement++;
                ar[currElement]=x.first;
                p[currElement] =x;


                int pos=currElement;

                while(ar[pos]<ar[pos/2] && pos/2>=1){
                    swap(ar[pos],ar[pos/2]);
                    swap(p[pos],p[pos/2]);
                    pos/=2;
                }
            }
        }

        int size()
        {
            return currElement;
        }

        pair<int,int> extract_min()
        {
            pair<int,int> temp;
            temp = p[1];
            deleteKey();
            return temp; //In a Max-Heap the root is the greatest element
        }

        void deleteKey()
        {
            ar[1] = ar[currElement]; //make root equal to the last element,therefore deleteing the root
            p[1] = p[currElement];
            currElement--; //reduce element count
            maxHeapify(1); //restore maxHeap property
        }


};

      
