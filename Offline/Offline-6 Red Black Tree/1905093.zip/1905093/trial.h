#include <bits/stdc++.h>
using namespace std;

//Node structure for the tree cells
struct Node
{

    int key;
    Node *left;
    Node *right;
    int color;
    Node *parent;
    int child;
};

class redBlack
{

public:
    Node *root;
    Node *Tnil;
    int count;

    redBlack()
    {   //equating everthing to the sentinal node
        Tnil = new Node;
        Tnil->color = 0;
        Tnil->left = Tnil;
        Tnil->right = Tnil;
        Tnil->parent = Tnil;
        Tnil->child = 0;
        root = Tnil;
        count = 0;
    }

    void recurseCount(Node *temp)
    {
        int n = 0;

        if (temp == Tnil)
        {
            return;
        }

        if (temp->left != Tnil)
        {
            n += temp->left->child;
        }

        if (temp->right = Tnil)
        {
            n += temp->right->child;
        }

        temp->child += n + 1;

        recurseCount(temp->parent);
    }

    bool insert(int p)
    {
        //Checking to see if value is already present in the tree
        if (search(p) == true)
        {
            return false;
        }

        //Make a new node with the key value
        Node *z = new Node();
        z->key = p;
        z->parent = Tnil;
        z->left = Tnil;
        z->right = Tnil;
        z->color = 1;
        z->child = 0;
        Node *y = Tnil;
        Node *x = root;

        //Find the to-be-parent of the new node x
        while (x != Tnil)
        {
            y = x;
            if (z->key < x->key)
            {
                x = x->left;
            }
            else
            {
                x = x->right;
            }
        }

        z->parent = y;

        if (y == Tnil)
        {
            root = z;
        }

        else if (z->key < y->key)
        {
            y->left = z;
        }

        else
        {
            y->right = z;
        }

        //Backtrack along the parents and increase each of their child count by 1
        Node* t=z;
        while(t!=Tnil){
            t->child++;
            t=t->parent;
        }

        insertFixup(z);
        count++;

        return true;
    }

    //
    void rbtransplant(Node *u, Node *v)
    {
        if (u->parent == Tnil)
        {
            root = v;
        }
        else if (u == u->parent->left)
        {
            u->parent->left = v;
        }
        else
        {
            u->parent->right = v;
        }
        v->parent = u->parent;
    }

    
    void leftRotate(Node *x)
    {

        // Child count in respect to rotation
        Node *y = x->right;

        x->child += -y->child + y->left->child;
        y->child += -y->left->child + x->child;

        
        x->right = y->left;

        if (y->left != Tnil)
        {
            y->left->parent = x;
        }
        y->parent = x->parent;

        if (x->parent == Tnil)
        {
            root = y;
        }

        else if (x == x->parent->left)
        {
            x->parent->left = y;
        }

        else
        {
            x->parent->right = y;
        }

        y->left = x;
        x->parent = y;

    }

    void rightRotate(Node *x)
    {
        // Child count in respect to rotation
        Node *y = x->left;

        x->child += -y->child + y->right->child;
        y->child += -y->right->child + x->child;

        x->left = y->right;

        if (y->right != Tnil)
        {
            y->right->parent = x;
        }
        y->parent = x->parent;

        if (x->parent == Tnil)
        {
            root = y;
        }

        else if (x == x->parent->right)
        {
            x->parent->right = y;
        }

        else
        {
            x->parent->left = y;
        }

        y->right = x;
        x->parent = y;
    }

    void insertFixup(Node *x)
    {
        Node *y;
        while (x->parent->color == 1)
        {
            if (x->parent == x->parent->parent->left)
            {
                y = x->parent->parent->right;

                if (y->color == 1)
                {
                    x->parent->color = 0;
                    y->color = 0;
                    x->parent->parent->color = 1;
                    x = x->parent->parent;
                }

                else
                {
                    if (x == x->parent->right)
                    {
                        x = x->parent;
                        leftRotate(x);
                    }

                    x->parent->color = 0;
                    x->parent->parent->color = 1;
                    rightRotate(x->parent->parent);
                }
            }

            else
            {
                if (x->parent == x->parent->parent->right)
                {
                    y = x->parent->parent->left;

                    if (y->color == 1)
                    {
                        x->parent->color = 0;
                        y->color = 0;
                        x->parent->parent->color = 1;
                        x = x->parent->parent;
                    }

                    else
                    {
                        if (x == x->parent->left)
                        {
                            x = x->parent;
                            rightRotate(x);
                        }

                        x->parent->color = 0;
                        x->parent->parent->color = 1;
                        leftRotate(x->parent->parent);
                    }
                }
            }
        }
        root->color = 0;
    }

    bool deleteNode(int temp)
    {  
        Node *y, *x, *parent;
        Node *z = new Node();
        z = Tnil;
       
        Node *ptr = root;
        while (ptr != Tnil)
        {
            if (ptr->key == temp)
            {
                z = ptr;
                break;
            }

            if (ptr->key <= temp)
            {
                ptr = ptr->right;
            }
            else
            {
                ptr = ptr->left;
            }
        }

        if (z == Tnil)
        {
            return false;
        }

        y = z;

        int y_original_color = y->color;
        if (z->left == Tnil)
        {
            x = z->right;
            rbtransplant(z, z->right);
        }
        else if (z->right == Tnil)
        {
            x = z->left;
            rbtransplant(z, z->left);
        }
        else
        {
            y = findMin(z->right);
            y_original_color = y->color;
            x = y->right;

            if (y->parent == z)
            {
                x->parent = y;
            }

            else
            {
                rbtransplant(y, y->right);
                y->right = z->right;
                y->right->parent = y;
            }
            rbtransplant(z, y);
            y->child=z->child;
            y->left = z->left;
            y->left->parent = y;
            y->color = z->color;
        }
        Node *u = x->parent;
        while (u != Tnil)
        {
            u->child--;
            u = u->parent;
        }
        if (y_original_color == 0)
        {
            deletefix(x);
        }

        return true;
    }

    bool deletefunc(int temp)
    {
        Node *y, *x;
        Node *z = new Node();
        z = Tnil;

        Node *ptr = root;
        while (ptr != Tnil)
        {
            if (ptr->key == temp)
            {
                z = ptr;
            }

            if (ptr->key <= temp)
            {
                ptr = ptr->right;
            }
            else
            {
                ptr = ptr->left;
            }
        }

        if (z == Tnil)
        {
            return false;
        }

        if (z->left == Tnil or z->right == Tnil)
        {
            y = z;
        }
        else
            y = findMin(z->right);

        if (y->left == Tnil)
        {
            x = y->left;
        }
        else
        {
            x = y->right;
        }

        x->parent = y->parent;
        if (y->parent == Tnil)
        {
            root = x;
        }
        else if (y == y->parent->left)
        {
            y->parent->left = x;
        }
        else
        {
            y->parent->right = x;
        }

        if (y != z)
        {
            z->key = y->key;
        }

        if (y->color == 0)
        {
            deletefix(x);
        }

        return true;
    }

    void deletefix(Node *z)
    {
        while (z->color = 0 && z != root)
        {
            if (z->parent->left == z)
            {
                Node *w;
                w = z->parent->right;
                if (w->color == 1)
                {
                    w->color = 0;
                    z->parent->color = 1;
                    leftRotate(z->parent);
                    w = z->parent->right;
                }

                if (w->left->color == 0 && w->right->color == 0)
                {
                    w->color = 1;
                    z = z->parent;
                }
                else
                {
                    if (w->right->color == 0)
                    {
                        w->left->color = 0;
                        w->color = 1;
                        rightRotate(w);
                        w = z->parent->right;
                    }
                    w->color = z->parent->color;
                    z->parent->color = 0;
                    w->right->color = 0;
                    leftRotate(z->parent);
                    z = root;
                }
            }

            else
            {
                Node *w;
                w = z->parent->left;
                if (w->color == 1)
                {
                    w->color = 0;
                    z->parent->color = 1;
                    rightRotate(z->parent);
                    w = z->parent->left;
                }

                if (w->right->color == 0 && w->left->color == 0)
                {
                    w->color = 1;
                    z = z->parent;
                }
                else
                {
                    if (w->left->color == 0)
                    {
                        w->right->color = 0;
                        w->color = 1;
                        leftRotate(w);
                        w = z->parent->left;
                    }
                    w->color = z->parent->color;
                    z->parent->color = 0;
                    w->left->color = 0;
                    rightRotate(z->parent);
                    z = root;
                }
            }
        }
        z->color = 0;
    }

    Node *findMin(Node *x)
    {
        while (x->left != Tnil)
        {
            x = x->left;
        }
        return x;
    }

    Node *treeSuccessor(Node *z)
    {
        Node *temp = Tnil;

        if (z->right != Tnil)
        {
            return findMin(z->right);
        }

        temp = z->parent;
        while (temp != Tnil && z == temp->right)
        {
            z = temp;
            temp = temp->parent;
        }
        return temp;
    }

    bool search(int temp)
    { 
        Node *ptr = root;
        bool flag = false;

        while (ptr != Tnil)
        {   
            
            if (ptr->key == temp)
            {
                flag = true;
                break;
            }
            else if (ptr->key < temp)
            {
                ptr = ptr->right;
            }
            else if (ptr->key > temp)
            {
                ptr = ptr->left;
            }
        }

        return flag;
    }

    int find(Node *t,int x, int child)
    {
        if(t==Tnil){
            return child;
        }

        if(t->key == x){
            child += t->left->child;
            return child;
        }

        if(t->key > x){
            return find(t->left , x , child); 
        }

        // else if(t->left != Tnil){
        //     child += t->left->child;
        // }

        if(t->key < x){
            child = child + t->left->child + 1;
            return find(t->right,  x , child);
        }

        return 0;
    }
};