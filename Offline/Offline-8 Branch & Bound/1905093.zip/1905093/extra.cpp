#include <bits/stdc++.h>
using namespace std;

const int maxVal = 1e9;
const int minVal = -1e9;
const int m = 10;

void matrixPrinter(array<array<int,10>,10> &ar, int n){

    //cout<<"We got for FixedColoum: "<<fixedCol<< ", fixedRow: "<<fixedRow<<" Level: "<<level<<" Order: "<<order<<endl;
    for(int i = 1 ; i<=n ; i++){
        for(int j =1 ; j<=n  ; j++){
            cout<<ar[i][j]<<" " ;

        }
        cout<<endl;
    }
}


class matrixSolver
{

public:
    array<array<int, 10>, 10> matrix;
    int rowFixed;
    int coloumFixed;
    int bound;
    int level;
    int order;
    int dimension;

public:
    matrixSolver(array<array<int, 10>, 10> &ar, int r, int c, int l, int o, int n)
    {
        matrix = ar;
        rowFixed = r;
        coloumFixed = c;
        level = l;
        order = o;
        dimension=n;
        bound= boundValue(r,c,n);
        //cout<<bound<<endl;
    }

    matrixSolver()
    {
    }

    void takeinput(int n)
    {

        int t;
        for (int i = 1; i < n + 1; i++)
        {

            for (int j = 1; j < n + 1; j++)
            {
                // cout<<"Insider"<<endl;
                cin >> t;
                matrix[i][j] = t;
                // cout<<i<<" "<<j;
            }
        }
    }

    // void printMatrix(int n)
    // {
    //     for (int i = 1; i < n + 1; i++)
    //     {

    //         for (int j = 1; j < n + 1; j++)
    //         {
    //             // cout<<"Insider"<<endl;
    //             // cin>>t;
    //             cout << matrix[i][j] << " ";
    //             // cout<<i<<" "<<j;
    //         }
    //         cout << endl;
    //     }
    // }


    //Finds the unfixedbound value for all the coloums
    int unfixedBoundColoum(int fixedColoums, int fixedRows, int n)
    {
        int tempMax = minVal;

        for (int i = fixedColoums + 1; i <=n ; i++)
        {
            int temp = 0;
            for (int j = fixedRows + 1; j <= n ; j++)
            {
                if (matrix[j][i] == 1)
                {
                    temp++;
                }
            }
            if (temp > tempMax)
            {
                tempMax = temp;
            }
        }
        return tempMax;
    }


    //Finds the unfixedbound value for all the rows
    int unfixedBoundRows(int fixedColoums, int fixedRows, int n)
    {
        int tempMax = minVal;

        for (int i = fixedRows + 1; i <= n; i++)
        {
            int temp = 0;
            for (int j = fixedColoums + 1; j <=n; j++)
            {
                if (matrix[i][j] == 1)
                {
                    temp++;
                }
            }
            if (temp > tempMax)
            {
                tempMax = temp;
            }
        }

        return tempMax;
    }


    //Total unfixed Bound(From both coloum and rows)
    int unfixedBound(int fixedColoums, int fixedRows, int n)
    {

        int a = unfixedBoundColoum(fixedColoums, fixedRows, n);
        int b = unfixedBoundRows(fixedColoums, fixedRows, n);
        //cout << "They are :" << a << " " << b << endl;

        int x = (a > b) ? a : b;

        return floor((x + 1)*1.0 / 2.0);
    }

  

    //Checks if there is any x in the unfixed region for the corresponding row number
    int fixedCheckerRow(int fixedColoum, int fixedRows, int n, int rowNumber)
    {

        int temp = 0;
        for (int i = fixedColoum + 1; i <=n ; i++)
        {
            if (matrix[rowNumber][i] == 1)
            {
                temp++;
            }
        }

        return temp;
    }

   //Checks if there is any x in the unfixed region for the corresponding colounm number
    int fixedCheckerColoum(int fixedColoum, int fixedRows, int n, int coloumNumber)
    {
        int temp = 0;

        for (int i = fixedRows + 1; i <= n; i++)
        {
            if (matrix[i][coloumNumber] == 1)
            {
                temp++;
            }
        }
        return temp;
    }


    //Checks the furthest x from diagonal in the fixed region for that particular rownumber
    int utilRows(int fixedRows, int fixedColoums, int n, int rowNumber)
    {
        int temp1 = 1;
        for (int i = fixedColoums; i > rowNumber; i--)
        {
            // cout<<"Values now: "<<rowNumber<<","<<i<<endl;
            if (matrix[rowNumber][i] == 1)
            {
                temp1 = i - rowNumber + 1;
                break;
            }
        }

        int temp2 = 1;
        for (int i = 1; i < rowNumber; i++)
        {
            // cout<<"Values now: "<<rowNumber<<","<<i<<endl;
            if (matrix[rowNumber][i] == 1)
            {
                temp2 = rowNumber - i + 1;
                break;
            }
        }

        // cout<<"Left side: "<<temp2<<" Right side: "<<temp1<<endl;

        return (temp1 > temp2) ? temp1 : temp2;
    }

    int utilColoum(int fixedRows, int fixedColoums, int n, int coloumNumber)
    {
        int temp1 = 1;
        // For coloum lower side
        for (int i = fixedRows; i > coloumNumber; i--)
        {
            // cout<<"Values now: "<<i<<","<<coloumNumber<<endl;
            if (matrix[i][coloumNumber] == 1)
            {
                temp1 = i - coloumNumber + 1;
                break;
            }
        }

        // for coloum upper side
        int temp2 = 1;
        for (int i = 1; i < coloumNumber; i++)
        {
            // cout<<"Values now: "<<i<<","<<coloumNumber<<endl;
            if (matrix[i][coloumNumber] == 1)
            {
                temp2 = coloumNumber - i + 1;
                break;
            }
        }

        // cout<<"Top side: "<<temp2<<" Bottom side: "<<temp1<<endl;
        return (temp1 > temp2) ? temp1 : temp2;
    }

    int rowBound(int fixedRows, int fixedColoums, int n, int rowNumber)
    {
        int temp = 0;
        if (fixedCheckerRow(fixedColoums, fixedRows, n, rowNumber) == 0)
        {
            temp = utilRows(fixedRows, fixedColoums, n, rowNumber);
        }

        else
        {
            int x = fixedColoums + fixedCheckerRow(fixedColoums, fixedRows, n, rowNumber) - rowNumber + 1;
            int y = utilRows(fixedRows, fixedColoums, n, rowNumber);
            if (x > y)
            {
                temp = x;
            }
            else
            {
                temp = y;
            }
        }

        return temp;
    }

    int coloumBound(int fixedRows, int fixedColoums, int n, int coloumNumber)
    {
        int temp = 0;

        if (fixedCheckerColoum(fixedColoums, fixedRows, n, coloumNumber) == 0)
        {
            temp = utilColoum(fixedRows, fixedColoums, n, coloumNumber);
        }
        else
        {
            int x = fixedRows + fixedCheckerColoum(fixedColoums, fixedRows, n, coloumNumber) - coloumNumber + 1;
            int y = utilColoum(fixedRows, fixedColoums, n, coloumNumber);
            if (x > y)
            {
                temp = x;
            }
            else
            {
                temp = y;
            }
        }

        return temp;
    }

    int bandwidth(int fixedrow, int fixedcoloum, int n){
        int temp = minVal;
        for(int i =1 ;i<=n ; i++){
            int x = utilRows(fixedrow,fixedcoloum, n , i);
            if(x>temp){
                temp = x;
            }
        }

        return temp;
    }

    int boundValue(int fixedRows, int fixedColoums, int n)
    {

        int temp1 = minVal, temp2 = minVal;
        int x, y;
        for (int i = 1; i <= fixedRows; i++)
        {
            x = rowBound(fixedRows, fixedColoums, n, i);
            if (x > temp1)
            {
                temp1 = x;
            }
        }

        for (int i = 1; i <= fixedColoums; i++)
        {
            y = coloumBound(fixedRows, fixedColoums, n, i);
            if (y > temp2)
            {
                temp2 = y;
            }
        }

        int p = (temp1 > temp2) ? temp1 : temp2;
        //cout << "Value of p: " << p << endl;

        int q = unfixedBound(fixedColoums, fixedRows, n);

        return (p > q) ? p : q;
    }

    // bool operator<(const matrixSolver &b)
    // {

    //     cout<<"Harmano tecoinize me"<<endl;
    //     if (bound > b.bound)
    //     {
    //         cout<<"in1"<<endl;
    //         return true;
    //     }

    //     else if (bound == b.bound && level < b.level)
    //     {
    //         // cout<<"in2"<<endl;
    //         return true;
    //     }

    //     else if (bound == b.bound && level == b.level && order < b.order)
    //     {
    //          //cout<<"in3"<<endl;
    //         return true;
    //     }

    //     else
    //     {
    //          //cout<<"in4"<<endl;
    //         return false;
    //     }
    // }


    void printer(){
        cout<<endl;
        cout<<"The matrix is: "<<endl;
        matrixPrinter(matrix, dimension);
        cout<<"Here the parameters are: "<<endl;
        cout<<"Bound: "<<bound<<endl;
        cout<<"Level: "<<level<<endl;
        cout<<"Order: "<<order<<endl;
        cout<<"Fixed Coloums: "<<coloumFixed<<endl;
        cout<<"Fixed Rows: "<<rowFixed<<endl;
        cout<<endl;
    }
};

array<array<int,10>,10> brancoloum(int fixedColoum, array<array<int, 10>, 10> &mat, int n, int k)
{
   // cout<<"Here here : "<<fixedColoum<<" "<<n<<" " <<k<<endl;
    //matrixPrinter(mat,n);
    array<array<int, 10>, 10> temp;
    //for (int k = fixedColoum; k <= n; k++)
    {

        for (int i = 1; i < fixedColoum; i++)
        {
            for (int j = 1; j <= n; j++)
            {
                temp[j][i] = mat[j][i];
            }
        }
        //cout << "halted" << endl;
        for (int i = 1; i <= n; i++)
        {
            temp[i][fixedColoum] = mat[i][k];
        }

        int p = fixedColoum + 1;

        for (int i = fixedColoum; i <= n; i++)
        {
            for (int j = 1; j <= n; j++)
            {
                if (i != k)
                {
                    temp[j][p] = mat[j][i];
                }
            }
            if (i != k)
            {
                p++;
            }
        }

        return temp;
        // cout<<endl;
        // cout<<endl;
        // for (int i = 1; i <= n; i++)
        // {
        //     for (int j = 1; j <= n; j++)
        //     {
        //         cout << temp[i][j] << " ";
        //     }
        //     cout << endl;
        // }
    }
}

array<array<int,10>,10> branchRow(int fixedRows, array<array<int,10>,10> &mat, int n, int k){

    array<array<int,10>,10> temp;
    //for(int k = fixedRows; k<=n ;k++)
    {
        
        for(int i=1; i<fixedRows; i++){
            for(int j = 1; j<=n ;j++){
                temp[i][j] = mat[i][j];
            }
        }

        for(int i=1 ; i<=n ; i++){
            temp[fixedRows][i] = mat[k][i];
        }

        int p= fixedRows+1;

        for(int i =fixedRows; i<=n ; i++){
            for(int j = 1 ; j<=n ; j++){
                if(i!=k){
                    temp[p][j] = mat[i][j];
                }
            }
            if(i!=k){
                p++;
            }
        }

        return temp;

        // cout<<endl;
        // cout<<endl;

        // for (int i = 1; i <= n; i++)
        // {
        //     for (int j = 1; j <= n; j++)
        //     {
        //         cout << temp[i][j] << " ";
        //     }
        //     cout << endl;
        // }
    }


}

class compareCustom{
    public:
    bool operator()(matrixSolver & a, matrixSolver & b){

        //cout<<"Here the matrixes are: "<<endl;
        //matrixPrinter(a.matrix, a.coloumFixed, a.rowFixed, a.level, a.order);
        //matrixPrinter(b.matrix, b.coloumFixed, b.rowFixed, b.level, b.order);
        //a.printer();
        //b.printer();
        if (a.bound > b.bound)
        {
            //cout<<"in1"<<endl;
            return true;
        }

        else if (a.bound == b.bound && a.level > b.level)
        {
            // cout<<"in2"<<endl;
            return true;
        }

        else if (a.bound == b.bound && a.level == b.level && a.order < b.order)
        {
             //cout<<"in3"<<endl;
            return true;
        }

        else
        {
             //cout<<"in4"<<endl;
            return false;
        }
    }
};



int main()
{

    freopen("output.txt","w",stdout);


    // array<array<int,10>,10> temp;
    // int t;
    // for(int i = 1 ; i<=5; i++){
    //     for(int j =1; j<=5; j++){
    //         cin>>t;
    //         temp[i][j] = t;
    //     }
    // }

    //matrixSolver *mat = new matrixSolver(temp,0,0,0,1,1);

    //matrixSolver *mat = new matrixSolver();

    //mat->takeinput(5);
    //cout<<mat->unfixedBound(1,1,4)<<endl;
    //mat->printMatrix(4);

    // int limit = 3;
    // for(int i = 1; i<=limit; i++){
    //     cout<<mat->rowBound(3,limit,4,i)<<endl;
    // }

    // for(int i = 1; i<=limit; i++){
    //     cout<<mat->coloumBound(3,limit,4,i)<<endl;
    // }

    //cout<<mat->boundValue(3,3,5)<<endl;

    priority_queue<matrixSolver, vector<matrixSolver>, compareCustom> q;
    int n ;
    cin>>n;
    array<array<int, 10>, 10> temp;
    char t;
    for (int i = 1; i <= n; i++)
    {
        for (int j = 1; j <= n; j++)
        {
            cin >> t;
            if(t == 'X')
                temp[i][j] = 1;
            else
                temp[i][j]= (int)t -48;
        }
    }    

    //     cout<<"HAHA"<<endl;
    //     for (int i = 1; i <= n; i++)
    // {
    //     for (int j = 1; j <= n; j++)
    //     {
    //         cout<<temp[i][j]<<" ";
    //     }
    //     cout<<endl;
    // }    

    matrixSolver arr(temp,0,0,1,1,n); 

    int fixedColoum=0;
    int fixedRow =0;
    matrixSolver ans;
    q.push(arr);
    int counter =1;
    int level=2;
    while(true){

        matrixSolver ar = q.top();
        

        if(ar.rowFixed==n-1 && ar.coloumFixed==n-1){

            ans = q.top();
            q.pop();
            break;
        }
         
        q.pop();

        if(ar.rowFixed == ar.coloumFixed){
            fixedColoum++;
            //matrixPrinter(ar.matrix, ar.coloumFixed, ar.rowFixed, ar.level,ar.order);
            int order=1;
            for(int i=ar.coloumFixed+1 ; i<=n ; i++){
                array<array<int,10>,10> a = brancoloum(ar.coloumFixed+1, ar.matrix, n, i);
                //matrixPrinter(a,n);
                matrixSolver m(a,ar.rowFixed,ar.coloumFixed +1,ar.level +1,order,n);
                //m.printer();
                q.push(m);
                order++;
            }
        }

        else{
            fixedRow++;
            int order=1;
            for(int i =ar.rowFixed +1; i<=n ; i++){
                array<array<int,10>,10> a = branchRow(ar.rowFixed+1, ar.matrix, n, i);
                //matrixPrinter(a,fixedColoum,fixedRow,level,order);
                matrixSolver m(a,ar.rowFixed +1,ar.coloumFixed,ar.level +1, order,n);
                //m.printer();
                q.push(m);
                order++;
            }
        }

        counter++;
        level++;
        //cout<<"Done one time"<<endl;
    }

    for(int i =1; i<=n ; i++){
        for(int j =1; j<=n ; j++){
            if(ans.matrix[i][j]==1){
                cout<<'x'<<" ";
            }
            else{
                cout<<ans.matrix[i][j]<<" ";
            }

        }
        cout<<endl;
    }

    int x = ans.bandwidth(n,n,n);
    cout<<"Ans is: "<<x<<endl;

}